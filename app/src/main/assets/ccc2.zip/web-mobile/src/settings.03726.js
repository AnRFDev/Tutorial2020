window._CCSettings = {
    platform: "web-mobile",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/cases/sys/CallLocal.fire",
    orientation: "landscape",
    debug: true,
    jsList: [],
    bundleVers: {
        resources: "3c43f",
        internal: "a8060",
        main: "bb24e"
    }
};
